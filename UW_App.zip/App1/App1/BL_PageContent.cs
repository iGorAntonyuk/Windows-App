﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App1
{
    class BL_PageContent
    {
        public static string VarOutput { get; set; }
        public static string VarCredit { get; set; }
        public static string CreatedBy { get; set; }



        public static void CourseInfo()
        {






        }

        public static void Course1()
        {
            VarOutput = null;
            string[] names = new string[3] { "Course humber - CIS 4793C", "Course name - DBA", "Course description - Database Implementation Strategies for Programmers." };


            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "\r";
            }
            CourseCredits1();
        }


        public static void Course2()
        {
            VarOutput = null;
            string[] names = new string[3] { "Course humber - CIS 4836C", "Course name - WEB", "Course description - Web Analytics." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "\r";
            }
            CourseCredits2();
        }


        public static void Course3()
        {
            VarOutput = null;
            string[] names = new string[3] { "Course humber - CTS 3302C", "Course name - CLOUD", "Course description - Fundamentals of Cloud Computing." };

            for (int i = 0; i < names.Length; i++)
            {
                VarOutput = VarOutput + names[i] + "\r";
            }
            CourseCredits3();
        }

        public static void CourseCredits1()
        {
            VarCredit = null;
            string[] credits = new string[2] { "Course Credits - 4", "Course Prerequisuites - none" };

            for (int i = 0; i < credits.Length; i++)
            {
                VarCredit = VarCredit + credits[i] + "\r";
            }
        }

        public static void CourseCredits2()
        {
            VarCredit = null;
            string[] credits = new string[2] { "Course Credits - 4", "Course Prerequisuites - none" };

            for (int i = 0; i < credits.Length; i++)
            {
                VarCredit = VarCredit + credits[i] + "\r ";
            }
        }


        public static void CourseCredits3()
        {
            VarCredit = null;
            string[] credits = new string[2] { "Course Credits - 4", "Course Prerequisuites - none" };

            for (int i = 0; i < credits.Length; i++)
            {
                VarCredit = VarCredit + credits[i] + "\r";
            }
        }














    }

}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Popups;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public static string CreatedBy { get; set; }
        public MainPage()
        {
            this.InitializeComponent();
           
           // txtBoxFooter.Foreground = new SolidColorBrush(Windows.UI.Colors.Red);
          //  BL_PageContent.CreatedBy = "Created By: Igor Antonyuk";
           // txtBoxFooter.Text = BL_PageContent.CreatedBy;


        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Calc), null);
        }

        // method for degree page which takes to new page

        private void btnCourse1_Click(object sender, RoutedEventArgs e)
        {
            BL_PageContent.Course1();
           
            //.Text = BL_PageContent.VarOutput + BL_PageContent.VarCredit;
            this.Frame.Navigate(typeof(degree), null);
         
           

        }

      

            // method for faculty page which takes to new page

        private void staff1_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(Faculty), null);
        }
        // method for program vision  page which takes to new page
        private void Vision_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(ProgramVision), null);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace App1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class degree : Page
    {
        public degree()
        {
            this.InitializeComponent();
        }

        private void homepage_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage), null);
        }

        // methods for 14 degree courses wich populates information in text boxes

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string courseid = "CDA 3315C";
            string description = "This course is the study of business enterprise analysis, design, planning and implementation. It places focus on working with stakeholders, modeling business data flows and interfaces, determining the information security risk for an organization, and re-engineering business processes. Topics include current software development methodologies, business process modeling, and enterprise information security methodologies. This course will prepare students to work with stakeholders to ensure that information technology is in alignment with the goals of the business.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;

            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string courseid = "MAN 3504";
            string description = "In this course students examine the operations function of managing people, information, technology, materials, and facilities to produce goods and services. Specific areas covered will include: designing and managing operations; purchasing raw materials; controlling and maintaining inventories; and producing good or services that meet customers' expectations. Quantitative modeling will be used for solving business problems.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string courseid = "CDA 3428C";
            string description = "This course is the study of the design and use of distributed software applications as part of a enterprise architecture in a typical business. It places focus on the software development process, business process analysis, and generating functional requirements for business technology. Topics include software architecture, business process analysis, agile development, and scalability. This course will prepare students for producing a software development project plan, documenting hardware and software requirements to support current and future transaction loads, and modeling end-to-end data flows for a given business process.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 3801C";
            string description = "This course presents the fundamentals of mobile web applications development. It places a focus on implementing well-defined mobile application standards, while designing a mobile application as a business solution to a real business scenario. Topics include mobile application standards, selecting appropriate content adaptation strategies, and following the system's development life cycle to plan, design, test, and deploy a mobile application. This course will prepare students to develop a professional mobile application that meets today’s business standards.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 4655C";
            string description = "This course is the study of advanced mobile application development. It places a detailed focus on building a mobile application user interface, planning and designing database models, and deploying mobile applications to emulators, as well as popular mobile application stores. Topics include designing a professional graphical prototype of the user interface, designing navigation that meets usability requirements, constructing data models and databases, interfacing code to databases, and testing then deploying an application to popular application stores. This course will prepare students to create more advanced mobile applications that interact with cloud-based databases.";
            string prereq = "Fundamentals of Mobile Web Applications Development";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            string courseid = "GEB 3422";
            string description = "This course is a study of the characteristics and functions of project management, team building, and facilitation. It places focus on project planning, scope, scheduling, and controlling of projects through completion. It reinforces and builds upon skills and knowledge students have learned in all of the various disciplines within the Business curriculum. It is recommended that students take this course their final quarter";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            string courseid = "CTS 4557";
            string description = "This course is the study of emerging technologies. It places focus on technology impact on business and society in general. Topics include the relationship between emerging technologies and business opportunities, analysis of costs and savings of implementing particular technologies, legal and ethical issues affecting technology, challenges of adapting new technologies, and impacts of technology.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_7(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 3917C";
            string description = "This course is the study of distributed databases and the technical architecture they reside on. It places focus on geographically separated databases where through database replication, end users experience database transparency. Topics include the differences between distributed databases and stand-alone database management systems, scalability, replication, and overall high availability concepts as they relate to distributed databases. This course will prepare students to implement enterprise worthy, geographically separated databases.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_8(object sender, RoutedEventArgs e)
        {
            string courseid = "CTS 3265C";
            string description = "This course is the study of the skills and techniques for analyzing business performance data to provide support for business planning. It places focus on using query development, reporting, and analytical tools to help guide business decision-making. Topics include statistical analysis, basic database design, and business process modeling. This course will prepare students to utilize information to support decision-making.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_9(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 4793C";
            string description = "The focus of this course is to provide programmers the information necessary to interface mobile software applications with cloud-based distributed databases. Topics include a review of database fundamentals, database connectivity, query optimization, and the use of application program interfaces (APIs) as they relate to specific vendor databases. This course will prepare students to extract data from a distributed database and then present the data within a mobile software application.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_10(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 4836C";
            string description = "This course is the study of contemporary business analytics tools. It places a focus on determining the most appropriate product or technology for building data visualizations and dashboards. Topics include identifying analytical tools, highlighting various input and output data formats, identifying different types of data visualizations, and constructing business-oriented dashboards. This course will prepare students to be able to create data visualizations and dashboards based on provided business requirements.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_11(object sender, RoutedEventArgs e)
        {
            string courseid = "CTS 3302C";
            string description = "This course will introduce students to various technologies and services utilized in cloud computing. The course will focus on practical application of cloud deployment methodologies.Topics include the evolution of cloud computing technology, examination of cloud deployment and cloud service models, and designing a cloud computing strategy to meet specific business needs.";
            string prereq = "None";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_12(object sender, RoutedEventArgs e)
        {
            string courseid = "CTS 4623C";
            string description = "This course will provide students with an in-depth understanding of computing technologies and services for enterprise level application deployment projects. The course will focus on practical aspects of cloud based application architecture and deployment methodologies, using the Microsoft Azure cloud platform. Topics include application scalability principles, application performance and benchmarking tools, authentication and authorization security issues, cloud deployment platform selection criteria, asset cataloging and management, and other advanced cloud deployment topics.";
            string prereq = "Cloud Computing Fundamentals";
            string credits = "4";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }

        private void Button_Click_13(object sender, RoutedEventArgs e)
        {
            string courseid = "CIS 4910C";
            string description = "This course is the culmination of the diverse skill set previously gained throughout the program. It places focus on project management skills, communication, and critical thinking as they relate to constructing an end-to-end technical solution. This course will incorporate a different project focus each term where students will collaborate in the development of a mobile/cloud application system.";
            string prereq = "Technology Bachelor's student in final term";
            string credits = "3";

            textBox1.Text = courseid;
            textBox2.Text = description;
            textBox3.Text = prereq;
            textBox4.Text = credits;
        }
    }
}
